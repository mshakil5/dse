<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AssesmentHealthProblem extends Model
{
    use HasFactory;

    public function assesmentHealthComment()
    {
        return $this->hasMany(AssesmentHealthComment::class);
    }
}
